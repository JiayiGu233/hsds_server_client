#!/bin/bash

#
# Shutdown HSDS with "docker compose down" using the appropriate compose file
#
./runall.sh --stop
