docker build  -f Dockerfile.lambda -t hslambda .
