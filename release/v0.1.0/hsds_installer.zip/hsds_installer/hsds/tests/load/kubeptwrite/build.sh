docker build -t hsclient/load-kubeptwrite .
