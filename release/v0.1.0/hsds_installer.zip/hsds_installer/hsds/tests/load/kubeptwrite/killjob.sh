kubectl delete job load-kubeptwrite
