#!/bin/bash
cd /usr/local/src
python -u rand_write.py 
