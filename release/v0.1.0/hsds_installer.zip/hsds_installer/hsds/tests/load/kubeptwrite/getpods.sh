kubectl get pods --selector=job-name=load-kubeptwrite
