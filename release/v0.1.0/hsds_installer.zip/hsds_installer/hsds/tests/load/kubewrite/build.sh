docker build -t hsclient/load-kubewrite .
