#!/bin/bash
cd /usr/local/src
python -u write_slice.py 
