kubectl describe jobs load-kubewrite
