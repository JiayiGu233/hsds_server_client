kubectl delete job load-kubewrite
