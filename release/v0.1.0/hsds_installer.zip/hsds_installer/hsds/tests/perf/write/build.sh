docker build -t hdfgroup/hswritetest .
