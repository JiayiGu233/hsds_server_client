kubectl create configmap hsds-config --from-file=admin/config/config.yml 
kubectl create configmap hsds-override --from-file=admin/config/override.yml
