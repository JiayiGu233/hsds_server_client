#!/bin/sh
# start SN node
./run.sh sn
