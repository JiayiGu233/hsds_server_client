#!/bin/sh
# start DN node
./run.sh dn
