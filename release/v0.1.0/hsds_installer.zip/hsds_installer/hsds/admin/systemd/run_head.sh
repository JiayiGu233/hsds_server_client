#!/bin/sh
# start HEAD node
./run.sh head
